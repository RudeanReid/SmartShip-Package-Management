package smartship.ui;

import smartship.model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class ManagerFrame extends JFrame {

    private final User loggedInUser;
    private CardLayout contentLayout;
    private JPanel contentPanel;

    public ManagerFrame(User user) {
        this.loggedInUser = user;

        setTitle("SmartShip - Manager Portal");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 650);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // ----- SIDEBAR -----
        JPanel sidebar = new JPanel();
        sidebar.setBackground(new Color(30, 34, 45));
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setPreferredSize(new Dimension(220, 0));

        JLabel appLabel = new JLabel("SmartShip", SwingConstants.CENTER);
        appLabel.setForeground(Color.WHITE);
        appLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
        appLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        sidebar.add(appLabel);

        sidebar.add(makeSidebarSeparator());

        JButton btnDashboard = createSidebarButton("Dashboard");
        JButton btnShipments = createSidebarButton("Shipments");
        JButton btnUsers = createSidebarButton("Users");
        JButton btnReports = createSidebarButton("Reports");
        JButton btnLogout = createSidebarButton("Logout");

        btnDashboard.addActionListener(e -> showCard("dashboard"));
        btnShipments.addActionListener(e -> showCard("shipments"));
        btnUsers.addActionListener(e -> showCard("users"));
        btnReports.addActionListener(e -> showCard("reports"));
        btnLogout.addActionListener(e -> {
            dispose();
            new LoginFrame().setVisible(true);
        });

        sidebar.add(btnDashboard);
        sidebar.add(btnShipments);
        sidebar.add(btnUsers);
        sidebar.add(btnReports);

        sidebar.add(Box.createVerticalGlue());
        sidebar.add(makeSidebarSeparator());
        sidebar.add(btnLogout);

        add(sidebar, BorderLayout.WEST);

        // ----- TOP BAR -----
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(new Color(45, 50, 65));
        topBar.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JLabel pageTitle = new JLabel("Manager Dashboard");
        pageTitle.setForeground(Color.WHITE);
        pageTitle.setFont(new Font("SansSerif", Font.BOLD, 18));

        JLabel userLabel = new JLabel(
                "Logged in as: " + user.getFirstName() + " (" + user.getRole() + ")"
        );
        userLabel.setForeground(Color.LIGHT_GRAY);

        topBar.add(pageTitle, BorderLayout.WEST);
        topBar.add(userLabel, BorderLayout.EAST);

        add(topBar, BorderLayout.NORTH);

        // ----- CONTENT AREA (cards) -----
        contentLayout = new CardLayout();
        contentPanel = new JPanel(contentLayout);

        contentPanel.add(createDashboardPanel(), "dashboard");
        contentPanel.add(createShipmentsPanel(), "shipments");
        contentPanel.add(createUsersPanel(), "users");
        contentPanel.add(createReportsPanel(), "reports");

        add(contentPanel, BorderLayout.CENTER);

        showCard("dashboard");
    }

    // Helper: create sidebar button
    private JButton createSidebarButton(String text) {
        JButton btn = new JButton(text);
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setFocusPainted(false);
        btn.setForeground(Color.WHITE);
        btn.setBackground(new Color(45, 50, 65));
        btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btn.setHorizontalAlignment(SwingConstants.LEFT);

        btn.addChangeListener(e -> {
            if (btn.getModel().isRollover()) {
                btn.setBackground(new Color(60, 70, 90));
            } else {
                btn.setBackground(new Color(45, 50, 65));
            }
        });
        return btn;
    }

    private JComponent makeSidebarSeparator() {
        JSeparator sep = new JSeparator();
        sep.setForeground(new Color(70, 75, 90));
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        return sep;
    }

    private void showCard(String name) {
        contentLayout.show(contentPanel, name);
    }

    // ====== PANELS FOR EACH SECTION ======

    private JPanel createDashboardPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 246, 250));

        // top cards
        JPanel cards = new JPanel(new GridLayout(1, 3, 15, 15));
        cards.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
        cards.setOpaque(false);

        cards.add(createStatCard("Total Shipments", "120"));
        cards.add(createStatCard("Pending Deliveries", "23"));
        cards.add(createStatCard("Active Drivers", "8"));

        panel.add(cards, BorderLayout.NORTH);

        // table placeholder
        String[] cols = {"Shipment #", "Customer", "Status", "Date"};
        Object[][] data = {
                {"SHP176333129", "John Brown", "Pending", "2025-11-16"},
                {"SHP176333130", "Mary Blue", "Delivered", "2025-11-15"},
                {"SHP176333131", "ACME Ltd", "In Transit", "2025-11-15"}
        };

        JTable table = new JTable(new DefaultTableModel(data, cols));
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createTitledBorder("Recent Shipments"));

        panel.add(scroll, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createShipmentsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 246, 250));
        JLabel lbl = new JLabel("Shipments Management (design only)", SwingConstants.CENTER);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 18));
        panel.add(lbl, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createUsersPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 246, 250));
        JLabel lbl = new JLabel("Users / Staff Management (design only)", SwingConstants.CENTER);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 18));
        panel.add(lbl, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createReportsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 246, 250));
        JLabel lbl = new JLabel("Reports & Analytics (design only)", SwingConstants.CENTER);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 18));
        panel.add(lbl, BorderLayout.CENTER);
        return panel;
    }

    // small “card” for stats
    private JPanel createStatCard(String title, String value) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        JLabel lblTitle = new JLabel(title);
        lblTitle.setForeground(Color.GRAY);
        lblTitle.setFont(new Font("SansSerif", Font.PLAIN, 14));

        JLabel lblValue = new JLabel(value);
        lblValue.setFont(new Font("SansSerif", Font.BOLD, 24));
        lblValue.setForeground(new Color(0, 120, 215));

        card.add(lblTitle, BorderLayout.NORTH);
        card.add(lblValue, BorderLayout.CENTER);

        card.setPreferredSize(new Dimension(0, 80));
        return card;
    }
}
