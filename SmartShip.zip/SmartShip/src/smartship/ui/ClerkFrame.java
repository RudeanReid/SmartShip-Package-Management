package smartship.ui;

import smartship.dao.ClerkDAO;
import smartship.model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ClerkFrame extends JFrame {

    private final User clerkUser;
    private final ClerkDAO dao = new ClerkDAO();

    private JTable table;
    private JComboBox<String> driverBox;
    private JComboBox<String> vehicleBox;
    private JComboBox<String> scheduleBox;

    public ClerkFrame(User user) {
        this.clerkUser = user;

        setTitle("SmartShip - Clerk Portal");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // ----- SIDEBAR -----
        JPanel sidebar = new JPanel();
        sidebar.setBackground(new Color(30, 34, 45));
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setPreferredSize(new Dimension(220, 0));

        JLabel appLabel = new JLabel("SmartShip", SwingConstants.CENTER);
        appLabel.setForeground(Color.WHITE);
        appLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
        appLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        sidebar.add(appLabel);

        sidebar.add(makeSidebarSeparator());

        JButton btnAssign = createSidebarButton("Assign Shipments");
        JButton btnRefresh = createSidebarButton("Refresh Data");
        JButton btnLogout = createSidebarButton("Logout");

        btnAssign.addActionListener(e -> {
            // currently only one main view, but hook here if you add more later
        });

        btnRefresh.addActionListener(e -> loadData());

        btnLogout.addActionListener(e -> {
            dispose();
            new LoginFrame().setVisible(true);
        });

        sidebar.add(btnAssign);
        sidebar.add(btnRefresh);
        sidebar.add(Box.createVerticalGlue());
        sidebar.add(makeSidebarSeparator());
        sidebar.add(btnLogout);

        add(sidebar, BorderLayout.WEST);

        // ----- TOP BAR -----
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(new Color(45, 50, 65));
        topBar.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JLabel pageTitle = new JLabel("Clerk Dashboard - Shipment Assignment");
        pageTitle.setForeground(Color.WHITE);
        pageTitle.setFont(new Font("SansSerif", Font.BOLD, 18));

        JLabel userLabel = new JLabel("Logged in as: " + clerkUser.getFirstName() + " (CLERK)");
        userLabel.setForeground(Color.LIGHT_GRAY);

        topBar.add(pageTitle, BorderLayout.WEST);
        topBar.add(userLabel, BorderLayout.EAST);

        add(topBar, BorderLayout.NORTH);

        // ----- CENTER CONTENT -----
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(245, 246, 250));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // title text inside center
        JLabel centerTitle = new JLabel("Pending Shipments", SwingConstants.LEFT);
        centerTitle.setFont(new Font("SansSerif", Font.BOLD, 16));
        centerTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        mainPanel.add(centerTitle, BorderLayout.NORTH);

        // table in the middle
        table = new JTable();
        table.setModel(new DefaultTableModel(
                new Object[]{"ID", "Shipment #", "Sender", "Recipient", "Cost"}, 0
        ));

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Pending Shipments"));
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // bottom assignment panel
        JPanel assignmentPanel = new JPanel();
        assignmentPanel.setBackground(new Color(245, 246, 250));
        assignmentPanel.setLayout(new GridBagLayout());
        assignmentPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 10, 5, 10);
        c.fill = GridBagConstraints.HORIZONTAL;

        driverBox = new JComboBox<>();
        vehicleBox = new JComboBox<>();
        scheduleBox = new JComboBox<>();

        JButton btnAssignShipment = new JButton("Assign Selected Shipment");
        stylePrimaryButton(btnAssignShipment);
        btnAssignShipment.addActionListener(e -> assignSelectedShipment());

        int row = 0;

        c.gridy = row; c.gridx = 0;
        assignmentPanel.add(new JLabel("Driver:"), c);
        c.gridx = 1;
        assignmentPanel.add(driverBox, c);

        c.gridy = row; c.gridx = 2;
        assignmentPanel.add(new JLabel("Vehicle:"), c);
        c.gridx = 3;
        assignmentPanel.add(vehicleBox, c);

        row++;
        c.gridy = row; c.gridx = 0;
        assignmentPanel.add(new JLabel("Schedule:"), c);
        c.gridx = 1;
        assignmentPanel.add(scheduleBox, c);

        c.gridx = 2; c.gridwidth = 2;
        assignmentPanel.add(btnAssignShipment, c);

        mainPanel.add(assignmentPanel, BorderLayout.SOUTH);

        add(mainPanel, BorderLayout.CENTER);

        // initial load
        loadData();
    }

    private JButton createSidebarButton(String text) {
        JButton btn = new JButton(text);
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setFocusPainted(false);
        btn.setForeground(Color.WHITE);
        btn.setBackground(new Color(45, 50, 65));
        btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btn.setHorizontalAlignment(SwingConstants.LEFT);

        btn.addChangeListener(e -> {
            if (btn.getModel().isRollover()) {
                btn.setBackground(new Color(60, 70, 90));
            } else {
                btn.setBackground(new Color(45, 50, 65));
            }
        });

        return btn;
    }

    private JComponent makeSidebarSeparator() {
        JSeparator sep = new JSeparator();
        sep.setForeground(new Color(70, 75, 90));
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        return sep;
    }

    private void stylePrimaryButton(JButton btn) {
        btn.setBackground(new Color(0, 120, 215));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setFont(new Font("SansSerif", Font.BOLD, 13));
        btn.setPreferredSize(new Dimension(200, 32));
    }

    // ====== DATA LOADING / ACTIONS ======

    private void loadData() {
        // table
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);
        List<String[]> shipments = dao.getPendingShipments();
        for (String[] s : shipments) {
            model.addRow(s);
        }

        // drivers
        driverBox.removeAllItems();
        for (String[] d : dao.getDrivers()) {
            driverBox.addItem(d[0] + " - " + d[1]);
        }

        // vehicles
        vehicleBox.removeAllItems();
        for (String[] v : dao.getVehicles()) {
            vehicleBox.addItem(v[0] + " - " + v[1]);
        }

        // schedules
        scheduleBox.removeAllItems();
        for (String[] sc : dao.getSchedules()) {
            scheduleBox.addItem(sc[0] + " - " + sc[1]);
        }
    }

    private void assignSelectedShipment() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a shipment in the table.");
            return;
        }

        if (driverBox.getItemCount() == 0 ||
                vehicleBox.getItemCount() == 0 ||
                scheduleBox.getItemCount() == 0) {
            JOptionPane.showMessageDialog(this, "Please ensure drivers, vehicles and schedules exist.");
            return;
        }

        int shipmentId = Integer.parseInt(table.getValueAt(row, 0).toString());
        int driverId = Integer.parseInt(driverBox.getSelectedItem().toString().split(" - ")[0]);
        int scheduleId = Integer.parseInt(scheduleBox.getSelectedItem().toString().split(" - ")[0]);
        // vehicleId is not used in DAO currently; it's only for UI display

        boolean success = dao.assignShipment(shipmentId, driverId, scheduleId, clerkUser.getId());

        if (success) {
            JOptionPane.showMessageDialog(this, "Shipment assigned successfully!");
            loadData();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to assign shipment.");
        }
    }
}
