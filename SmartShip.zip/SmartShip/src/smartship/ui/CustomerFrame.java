package smartship.ui;

import smartship.dao.ShipmentDAO;
import smartship.model.Shipment;
import smartship.model.User;

import javax.swing.border.EmptyBorder;
import javax.swing.*;
import java.awt.*;
import java.sql.ResultSet;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;

public class CustomerFrame extends JFrame {

    private final User loggedInUser;
    private final ShipmentDAO shipmentDAO = new ShipmentDAO();

    // Card layout for center content
    private CardLayout cardLayout;
    private JPanel cardPanel;

    // Create shipment fields
    private JTextField txtSender;
    private JTextField txtRecipient;
    private JTextField txtZone;
    private JTextField txtWeight;
    private JComboBox<String> cmbType;
    private JTextField txtLength;
    private JTextField txtHeight;
    private JLabel lblCreateResult;

    // Track / My Shipments fields
    private JTextField txtTrackNumber;
    private JTextArea txtTrackResult;

    public CustomerFrame(User user) {
        this.loggedInUser = user;

        setTitle("SmartShip - Customer Portal");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // ===== SIDEBAR =====
        JPanel sidebar = new JPanel();
        sidebar.setBackground(new Color(30, 34, 45));
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setPreferredSize(new Dimension(220, 0));

        JLabel appLabel = new JLabel("SmartShip", SwingConstants.CENTER);
        appLabel.setForeground(Color.WHITE);
        appLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
        appLabel.setBorder(new EmptyBorder(20, 0, 20, 0));
        sidebar.add(appLabel);

        sidebar.add(makeSidebarSeparator());

        JButton btnMyShipments = createSidebarButton("My Shipments");
        JButton btnCreateShipment = createSidebarButton("Create Shipment");
        JButton btnProfile = createSidebarButton("Profile");
        JButton btnLogout = createSidebarButton("Logout");

        btnMyShipments.addActionListener(e -> showCard("track"));
        btnCreateShipment.addActionListener(e -> showCard("create"));
        btnProfile.addActionListener(e -> showCard("profile"));
        btnLogout.addActionListener(e -> {
            dispose();
            new LoginFrame().setVisible(true);
        });

        sidebar.add(btnMyShipments);
        sidebar.add(btnCreateShipment);
        sidebar.add(btnProfile);

        sidebar.add(Box.createVerticalGlue());
        sidebar.add(makeSidebarSeparator());
        sidebar.add(btnLogout);

        add(sidebar, BorderLayout.WEST);

        // ===== TOP BAR =====
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(new Color(45, 50, 65));
        topBar.setBorder(new EmptyBorder(10, 20, 10, 20));

        JLabel pageTitle = new JLabel("Customer Dashboard");
        pageTitle.setForeground(Color.WHITE);
        pageTitle.setFont(new Font("SansSerif", Font.BOLD, 18));

        JLabel userLabel = new JLabel("Welcome, " + loggedInUser.getFirstName());
        userLabel.setForeground(Color.LIGHT_GRAY);

        topBar.add(pageTitle, BorderLayout.WEST);
        topBar.add(userLabel, BorderLayout.EAST);

        add(topBar, BorderLayout.NORTH);

        // ===== CENTER CONTENT (cards) =====
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);
        cardPanel.setBackground(new Color(245, 246, 250));

        cardPanel.add(createHomePanel(), "home");
        cardPanel.add(createCreateShipmentPanel(), "create");
        cardPanel.add(createTrackPanel(), "track");
        cardPanel.add(createProfilePanel(), "profile");

        add(cardPanel, BorderLayout.CENTER);

        // Show default
        showCard("home");
    }

    // -------- Sidebar helpers --------
    private JButton createSidebarButton(String text) {
        JButton btn = new JButton(text);
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setFocusPainted(false);
        btn.setForeground(Color.WHITE);
        btn.setBackground(new Color(45, 50, 65));
        btn.setBorder(new EmptyBorder(10, 20, 10, 20));
        btn.setHorizontalAlignment(SwingConstants.LEFT);

        btn.addChangeListener(e -> {
            if (btn.getModel().isRollover()) {
                btn.setBackground(new Color(60, 70, 90));
            } else {
                btn.setBackground(new Color(45, 50, 65));
            }
        });

        return btn;
    }

    private JComponent makeSidebarSeparator() {
        JSeparator sep = new JSeparator();
        sep.setForeground(new Color(70, 75, 90));
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        return sep;
    }

    private void showCard(String name) {
        cardLayout.show(cardPanel, name);
    }

    // -------- Home panel --------
    private JPanel createHomePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 246, 250));

        JLabel text = new JLabel(
                "<html><div style='text-align:center;'>"
                        + "Welcome to SmartShip.<br/>"
                        + "Use the menu on the left to create a shipment or view your shipments."
                        + "</div></html>",
                SwingConstants.CENTER
        );
        text.setFont(new Font("SansSerif", Font.PLAIN, 18));
        panel.add(text, BorderLayout.CENTER);

        return panel;
    }

    // -------- Create Shipment panel --------
    private JPanel createCreateShipmentPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 246, 250));
        panel.setBorder(new EmptyBorder(15, 15, 15, 15));

        JLabel title = new JLabel("Create New Shipment");
        title.setFont(new Font("SansSerif", Font.BOLD, 18));
        panel.add(title, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);
        form.setBorder(new EmptyBorder(15, 15, 15, 15));

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1.0;

        int row = 0;

        // Sender
        c.gridy = row++;
        c.gridx = 0;
        form.add(new JLabel("Sender Info:"), c);
        c.gridx = 1;
        txtSender = new JTextField("Your Name / Address");
        form.add(txtSender, c);

        // Recipient
        c.gridy = row++;
        c.gridx = 0;
        form.add(new JLabel("Recipient Info:"), c);
        c.gridx = 1;
        txtRecipient = new JTextField("Recipient Name / Address");
        form.add(txtRecipient, c);

        // Zone
        c.gridy = row++;
        c.gridx = 0;
        form.add(new JLabel("Zone (1-4):"), c);
        c.gridx = 1;
        txtZone = new JTextField();
        form.add(txtZone, c);

        // Weight
        c.gridy = row++;
        c.gridx = 0;
        form.add(new JLabel("Weight (kg):"), c);
        c.gridx = 1;
        txtWeight = new JTextField();
        form.add(txtWeight, c);

        // Type
        c.gridy = row++;
        c.gridx = 0;
        form.add(new JLabel("Package Type:"), c);
        c.gridx = 1;
        cmbType = new JComboBox<>(new String[]{"STANDARD", "EXPRESS", "FRAGILE"});
        form.add(cmbType, c);

        // Dimensions
        c.gridy = row++;
        c.gridx = 0;
        form.add(new JLabel("Length (cm):"), c);
        c.gridx = 1;
        txtLength = new JTextField();
        form.add(txtLength, c);

        c.gridy = row++;
        c.gridx = 0;
        form.add(new JLabel("Height (cm):"), c);
        c.gridx = 1;
        txtHeight = new JTextField();
        form.add(txtHeight, c);

        // Button + result
        JPanel bottom = new JPanel(new BorderLayout());
        bottom.setBackground(Color.WHITE);
        bottom.setBorder(new EmptyBorder(10, 0, 0, 0));

        JButton btnCreate = new JButton("Create Shipment");
        stylePrimaryButton(btnCreate);
        btnCreate.addActionListener(e -> doCreateShipment());

        lblCreateResult = new JLabel(" ");
        lblCreateResult.setForeground(new Color(0, 120, 0));

        bottom.add(btnCreate, BorderLayout.WEST);
        bottom.add(lblCreateResult, BorderLayout.CENTER);

        c.gridy = row++;
        c.gridx = 0;
        c.gridwidth = 2;
        form.add(bottom, c);

        panel.add(form, BorderLayout.CENTER);
        return panel;
    }

    private void stylePrimaryButton(JButton btn) {
        btn.setBackground(new Color(0, 120, 215));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setFont(new Font("SansSerif", Font.BOLD, 13));
        btn.setPreferredSize(new Dimension(160, 32));
    }

    private void doCreateShipment() {
        try {
            String sender = txtSender.getText().trim();
            String recipient = txtRecipient.getText().trim();
            int zone = Integer.parseInt(txtZone.getText().trim());
            double weight = Double.parseDouble(txtWeight.getText().trim());
            String type = cmbType.getSelectedItem().toString();
            double length = Double.parseDouble(txtLength.getText().trim());
            double height = Double.parseDouble(txtHeight.getText().trim());

            if (sender.isEmpty() || recipient.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Sender and recipient are required.");
                return;
            }

            // Map users.id -> customers.id
            int customerId = shipmentDAO.findCustomerIdByUserId(loggedInUser.getId());
            if (customerId == -1) {
                JOptionPane.showMessageDialog(this,
                        "No customer profile found for this user.\nPlease contact support.");
                return;
            }

            // Build Shipment with correct FK (customers.id)
            Shipment s = new Shipment(
                    customerId,
                    sender,
                    recipient,
                    zone,
                    weight,
                    type
            );

            // Create shipment + package + invoice
            String shipmentNumber = shipmentDAO.createShipment(s, length, height, weight);

            if (shipmentNumber != null) {

                // Copy shipment number to clipboard
                Toolkit.getDefaultToolkit()
                        .getSystemClipboard()
                        .setContents(new StringSelection(shipmentNumber), null);

                lblCreateResult.setText("Shipment created! Number: " + shipmentNumber);
                JOptionPane.showMessageDialog(this,
                        "Shipment created successfully.\n\n"
                                + "Shipment Number: " + shipmentNumber
                                + "\n\n(The number has been copied to your clipboard.)");
            } else {
                lblCreateResult.setText("Failed to create shipment.");
                JOptionPane.showMessageDialog(this, "Failed to create shipment.");
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Please enter valid numeric values for zone, weight, length and height.");
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    // -------- My Shipments / Track panel --------
    private JPanel createTrackPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 246, 250));
        panel.setBorder(new EmptyBorder(15, 15, 15, 15));

        JLabel title = new JLabel("My Shipments / Track Shipment");
        title.setFont(new Font("SansSerif", Font.BOLD, 18));
        panel.add(title, BorderLayout.NORTH);

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.setBackground(new Color(245, 246, 250));

        top.add(new JLabel("Shipment Number:"));
        txtTrackNumber = new JTextField(20);
        top.add(txtTrackNumber);

        JButton btnTrack = new JButton("Track");
        stylePrimaryButton(btnTrack);
        btnTrack.addActionListener(e -> doTrackShipment());
        top.add(btnTrack);

        panel.add(top, BorderLayout.CENTER);

        txtTrackResult = new JTextArea(8, 40);
        txtTrackResult.setEditable(false);
        JScrollPane scroll = new JScrollPane(txtTrackResult);
        scroll.setBorder(BorderFactory.createTitledBorder("Shipment Details"));

        panel.add(scroll, BorderLayout.SOUTH);

        return panel;
    }

    private void doTrackShipment() {
        String number = txtTrackNumber.getText().trim();
        if (number.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter a shipment number.");
            return;
        }

        try {
            // Secure tracking: only shipments that belong to this logged-in user
            ResultSet rs = shipmentDAO.trackShipmentForCustomer(number, loggedInUser.getId());
            StringBuilder sb = new StringBuilder();

            if (rs != null && rs.next()) {
                sb.append("Shipment Number: ").append(rs.getString("shipment_number")).append("\n");
                sb.append("Sender: ").append(rs.getString("sender_info")).append("\n");
                sb.append("Recipient: ").append(rs.getString("recipient_info")).append("\n");
                sb.append("Status: ").append(rs.getString("status")).append("\n");
                sb.append("Zone: ").append(rs.getInt("zone")).append("\n");
                sb.append("Distance (km): ").append(rs.getDouble("distance_km")).append("\n");
                sb.append("Weight (kg): ").append(rs.getDouble("weight")).append("\n");
                sb.append("Cost: ").append(rs.getDouble("cost")).append("\n");
            } else {
                sb.append("No shipment found with that number for your account.");
            }

            txtTrackResult.setText(sb.toString());

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error tracking shipment: " + e.getMessage());
        }
    }

    // -------- Profile panel (simple) --------
    private JPanel createProfilePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 246, 250));
        panel.setBorder(new EmptyBorder(15, 15, 15, 15));

        JLabel title = new JLabel("My Profile");
        title.setFont(new Font("SansSerif", Font.BOLD, 18));
        panel.add(title, BorderLayout.NORTH);

        JTextArea info = new JTextArea();
        info.setEditable(false);
        info.setText("Name: " + loggedInUser.getFirstName() + " " + loggedInUser.getLastName() + "\n"
                + "Username: " + loggedInUser.getUsername() + "\n"
                + "Role: " + loggedInUser.getRole() + "\n");
        panel.add(new JScrollPane(info), BorderLayout.CENTER);

        return panel;
    }
}
