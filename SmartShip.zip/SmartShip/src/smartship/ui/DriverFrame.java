package smartship.ui;

import smartship.dao.DriverDAO;
import smartship.model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class DriverFrame extends JFrame {

    private final User driver;
    private final DriverDAO dao = new DriverDAO();

    private JTable table;
    private JComboBox<String> statusBox;

    public DriverFrame(User user) {
        this.driver = user;

        setTitle("SmartShip - Driver Portal");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // ----- SIDEBAR -----
        JPanel sidebar = new JPanel();
        sidebar.setBackground(new Color(30, 34, 45));
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setPreferredSize(new Dimension(220, 0));

        JLabel appLabel = new JLabel("SmartShip", SwingConstants.CENTER);
        appLabel.setForeground(Color.WHITE);
        appLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
        appLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        sidebar.add(appLabel);

        sidebar.add(makeSidebarSeparator());

        JButton btnMyDeliveries = createSidebarButton("My Deliveries");
        JButton btnRefresh = createSidebarButton("Refresh");
        JButton btnLogout = createSidebarButton("Logout");

        btnMyDeliveries.addActionListener(e -> loadShipments());
        btnRefresh.addActionListener(e -> loadShipments());
        btnLogout.addActionListener(e -> {
            dispose();
            new LoginFrame().setVisible(true);
        });

        sidebar.add(btnMyDeliveries);
        sidebar.add(btnRefresh);
        sidebar.add(Box.createVerticalGlue());
        sidebar.add(makeSidebarSeparator());
        sidebar.add(btnLogout);

        add(sidebar, BorderLayout.WEST);

        // ----- TOP BAR -----
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(new Color(45, 50, 65));
        topBar.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JLabel pageTitle = new JLabel("Driver Dashboard - Assigned Shipments");
        pageTitle.setForeground(Color.WHITE);
        pageTitle.setFont(new Font("SansSerif", Font.BOLD, 18));

        JLabel userLabel = new JLabel("Logged in as: " + driver.getFirstName() + " (DRIVER)");
        userLabel.setForeground(Color.LIGHT_GRAY);

        topBar.add(pageTitle, BorderLayout.WEST);
        topBar.add(userLabel, BorderLayout.EAST);

        add(topBar, BorderLayout.NORTH);

        // ----- CENTER CONTENT -----
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(245, 246, 250));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel centerTitle = new JLabel("My Assigned Shipments", SwingConstants.LEFT);
        centerTitle.setFont(new Font("SansSerif", Font.BOLD, 16));
        centerTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        mainPanel.add(centerTitle, BorderLayout.NORTH);

        // table
        table = new JTable();
        table.setModel(new DefaultTableModel(
                new Object[]{"ID", "Shipment #", "Sender", "Recipient", "Status"}, 0
        ));

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Assignments"));
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // bottom panel for status update
        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(new Color(245, 246, 250));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        statusBox = new JComboBox<>(new String[]{"IN_TRANSIT", "DELIVERED"});

        JButton btnUpdate = new JButton("Update Status");
        stylePrimaryButton(btnUpdate);
        btnUpdate.addActionListener(e -> updateStatus());

        bottomPanel.add(new JLabel("Set Status:"));
        bottomPanel.add(statusBox);
        bottomPanel.add(btnUpdate);

        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel, BorderLayout.CENTER);

        // initial load
        loadShipments();
    }

    private JButton createSidebarButton(String text) {
        JButton btn = new JButton(text);
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setFocusPainted(false);
        btn.setForeground(Color.WHITE);
        btn.setBackground(new Color(45, 50, 65));
        btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btn.setHorizontalAlignment(SwingConstants.LEFT);

        btn.addChangeListener(e -> {
            if (btn.getModel().isRollover()) {
                btn.setBackground(new Color(60, 70, 90));
            } else {
                btn.setBackground(new Color(45, 50, 65));
            }
        });

        return btn;
    }

    private JComponent makeSidebarSeparator() {
        JSeparator sep = new JSeparator();
        sep.setForeground(new Color(70, 75, 90));
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        return sep;
    }

    private void stylePrimaryButton(JButton btn) {
        btn.setBackground(new Color(0, 120, 215));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setFont(new Font("SansSerif", Font.BOLD, 13));
        btn.setPreferredSize(new Dimension(160, 32));
    }

    // ====== DATA / ACTIONS ======

    private void loadShipments() {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);

        List<String[]> shipments = dao.getAssignedShipments(driver.getId());
        for (String[] s : shipments) {
            model.addRow(s);
        }
    }

    private void updateStatus() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select a shipment first.");
            return;
        }

        int shipmentId = Integer.parseInt(table.getValueAt(row, 0).toString());
        String status = statusBox.getSelectedItem().toString();

        boolean ok = dao.updateShipmentStatus(shipmentId, status);
        if (ok) {
            JOptionPane.showMessageDialog(this, "Status updated.");
            loadShipments();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update status.");
        }
    }
}
