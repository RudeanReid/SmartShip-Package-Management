/**
 * LoginFrame
 *
 * Initial login window for the SmartShip application.
 * The user provides username and password and is then directed
 * to the correct portal depending on their role (Customer, Clerk,
 * Driver or Manager).
 */
package smartship.ui;

import smartship.dao.UserDAO;
import smartship.model.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class LoginFrame extends JFrame {

    private JTextField txtUser;
    private JPasswordField txtPass;
    private UserDAO userDAO = new UserDAO();

    public LoginFrame() {
        setTitle("SmartShip - Login");
        setSize(400, 260);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5,5,5,5);
        c.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblTitle = new JLabel("SmartShip Login", SwingConstants.CENTER);
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 18));
        c.gridx = 0; c.gridy = 0; c.gridwidth = 2;
        panel.add(lblTitle, c);

        c.gridwidth = 1;

        c.gridy = 1; c.gridx = 0;
        panel.add(new JLabel("Username:"), c);
        c.gridx = 1;
        txtUser = new JTextField();
        panel.add(txtUser, c);

        c.gridy = 2; c.gridx = 0;
        panel.add(new JLabel("Password:"), c);
        c.gridx = 1;
        txtPass = new JPasswordField();
        panel.add(txtPass, c);

        JButton btnLogin = new JButton("Login");
        btnLogin.addActionListener(e -> doLogin());
        c.gridy = 3; c.gridx = 0; c.gridwidth = 2;
        panel.add(btnLogin, c);

        // SIGN UP LINK
        JLabel lblSignup = new JLabel("No account? Sign up as Customer");
        lblSignup.setForeground(new Color(0, 120, 215));
        lblSignup.setCursor(new Cursor(Cursor.HAND_CURSOR));
        lblSignup.setHorizontalAlignment(SwingConstants.CENTER);

        lblSignup.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                new CustomerSignupFrame().setVisible(true);
            }
        });

        c.gridy = 4; c.gridx = 0; c.gridwidth = 2;
        panel.add(lblSignup, c);

        add(panel);
    }

    private void doLogin() {
        String username = txtUser.getText().trim();
        String password = new String(txtPass.getPassword());

        User user = userDAO.login(username, password);
        if (user == null) {
            JOptionPane.showMessageDialog(this, "Invalid credentials");
            return;
        }

        JOptionPane.showMessageDialog(this, "Welcome, " + user.getFirstName());

        dispose();
        switch (user.getRole()) {
            case "CUSTOMER":
                new CustomerFrame(user).setVisible(true);
                break;
            case "CLERK":
                new ClerkFrame(user).setVisible(true);
                break;
            case "DRIVER":
                new DriverFrame(user).setVisible(true);
                break;
            case "MANAGER":
                new ManagerFrame(user).setVisible(true);
                break;
        }
    }
}
