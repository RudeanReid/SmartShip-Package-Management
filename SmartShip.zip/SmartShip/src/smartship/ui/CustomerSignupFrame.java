package smartship.ui;

import smartship.dao.CustomerDAO;

import javax.swing.*;
import java.awt.*;
import java.net.URL;

public class CustomerSignupFrame extends JFrame {

    private JTextField txtFirstName;
    private JTextField txtLastName;
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JTextField txtPhone;
    private JTextField txtEmail;
    private JTextField txtAddress;
    private JTextField txtPayment;

    private final CustomerDAO customerDAO = new CustomerDAO();

    public CustomerSignupFrame() {
        setTitle("SmartShip - Customer Sign Up");
        setSize(900, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // close only this window
        setLayout(new BorderLayout());

        // ========= LEFT: custom GradientPanel with logo =========
        JPanel leftPanel = new GradientPanel();
        leftPanel.setLayout(new GridBagLayout());

        // load logo from same package: smartship/ui/smartship_logo.png
        URL logoUrl = CustomerSignupFrame.class.getResource("smartship_logo.png");
        JLabel lblLogo;
        if (logoUrl != null) {
            ImageIcon icon = new ImageIcon(logoUrl);
            Image img = icon.getImage().getScaledInstance(180, 180, Image.SCALE_SMOOTH);
            lblLogo = new JLabel(new ImageIcon(img));
        } else {
            // fallback – text only if logo not found
            lblLogo = new JLabel("SmartShip");
            lblLogo.setFont(new Font("SansSerif", Font.BOLD, 36));
            lblLogo.setForeground(Color.WHITE);
        }

        JLabel lblTitle = new JLabel("SmartShip");
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 32));

        JLabel lblSubtitle = new JLabel("Fast. Simple. Smart Delivery.");
        lblSubtitle.setForeground(Color.WHITE);
        lblSubtitle.setFont(new Font("SansSerif", Font.PLAIN, 16));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.insets = new Insets(10, 0, 10, 0);

        gbc.gridy = 0;
        leftPanel.add(lblLogo, gbc);
        gbc.gridy = 1;
        leftPanel.add(lblTitle, gbc);
        gbc.gridy = 2;
        leftPanel.add(lblSubtitle, gbc);

        // ========= RIGHT: white form panel =========
        JPanel formPanel = new JPanel();
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        formPanel.setLayout(new GridBagLayout());

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);
        c.anchor = GridBagConstraints.WEST;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1.0;

        int row = 0;

        JLabel lblHeader = new JLabel("Create Customer Account");
        lblHeader.setFont(new Font("SansSerif", Font.BOLD, 22));
        c.gridx = 0; c.gridy = row++; c.gridwidth = 2;
        formPanel.add(lblHeader, c);

        c.gridwidth = 1;

        // First Name
        c.gridy = row++; c.gridx = 0;
        formPanel.add(new JLabel("First Name:"), c);
        c.gridx = 1;
        txtFirstName = new JTextField();
        formPanel.add(txtFirstName, c);

        // Last Name
        c.gridy = row++; c.gridx = 0;
        formPanel.add(new JLabel("Last Name:"), c);
        c.gridx = 1;
        txtLastName = new JTextField();
        formPanel.add(txtLastName, c);

        // Username
        c.gridy = row++; c.gridx = 0;
        formPanel.add(new JLabel("Username:"), c);
        c.gridx = 1;
        txtUsername = new JTextField();
        formPanel.add(txtUsername, c);

        // Password
        c.gridy = row++; c.gridx = 0;
        formPanel.add(new JLabel("Password:"), c);
        c.gridx = 1;
        txtPassword = new JPasswordField();
        formPanel.add(txtPassword, c);

        // Phone
        c.gridy = row++; c.gridx = 0;
        formPanel.add(new JLabel("Phone:"), c);
        c.gridx = 1;
        txtPhone = new JTextField();
        formPanel.add(txtPhone, c);

        // Email
        c.gridy = row++; c.gridx = 0;
        formPanel.add(new JLabel("Email:"), c);
        c.gridx = 1;
        txtEmail = new JTextField();
        formPanel.add(txtEmail, c);

        // Address
        c.gridy = row++; c.gridx = 0;
        formPanel.add(new JLabel("Address:"), c);
        c.gridx = 1;
        txtAddress = new JTextField();
        formPanel.add(txtAddress, c);

        // Payment Method
        c.gridy = row++; c.gridx = 0;
        formPanel.add(new JLabel("Payment Method:"), c);
        c.gridx = 1;
        txtPayment = new JTextField("CARD");
        formPanel.add(txtPayment, c);

        // ========= Buttons =========
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnPanel.setBackground(Color.WHITE);

        JButton btnCancel = new JButton("Cancel");
        JButton btnSignUp = new JButton("Sign Up");

        stylePrimaryButton(btnSignUp);

        btnSignUp.addActionListener(e -> register());
        btnCancel.addActionListener(e -> dispose());

        btnPanel.add(btnCancel);
        btnPanel.add(btnSignUp);

        c.gridy = row++; c.gridx = 0; c.gridwidth = 2;
        formPanel.add(btnPanel, c);

        // add both sides to frame
        add(leftPanel, BorderLayout.WEST);
        add(formPanel, BorderLayout.CENTER);
    }

    private void register() {
        String firstName = txtFirstName.getText().trim();
        String lastName  = txtLastName.getText().trim();
        String username  = txtUsername.getText().trim();
        String password  = new String(txtPassword.getPassword());
        String phone     = txtPhone.getText().trim();
        String email     = txtEmail.getText().trim();
        String address   = txtAddress.getText().trim();
        String payment   = txtPayment.getText().trim();

        if (firstName.isEmpty() || lastName.isEmpty() ||
                username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "First name, last name, username and password are required.");
            return;
        }

        boolean ok = customerDAO.registerCustomer(
                username, password, firstName, lastName,
                phone, email, address, payment
        );

        if (ok) {
            JOptionPane.showMessageDialog(this,
                    "Account created successfully! You can now log in.");
            dispose();
        } else {
            JOptionPane.showMessageDialog(this,
                    "Failed to create account. Check logs.");
        }
    }

    private void stylePrimaryButton(JButton btn) {
        btn.setBackground(new Color(0, 120, 215)); // Windows blue
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setFont(new Font("SansSerif", Font.BOLD, 14));
        btn.setPreferredSize(new Dimension(120, 35));
    }

    /**
     * Simple gradient panel (no external libraries).
     */
    private static class GradientPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            int w = getWidth();
            int h = getHeight();
            Color color1 = new Color(58, 123, 213);
            Color color2 = new Color(123, 67, 151);
            GradientPaint gp = new GradientPaint(0, 0, color1, w, h, color2);
            g2d.setPaint(gp);
            g2d.fillRect(0, 0, w, h);
        }

        @Override
        public Dimension getPreferredSize() {
            return new Dimension(320, 0); // fixed width left panel
        }
    }
}
