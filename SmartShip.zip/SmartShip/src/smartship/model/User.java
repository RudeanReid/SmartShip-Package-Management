/**
 * User model class.
 *
 * Represents a record from the "users" table.
 * A user can be one of four roles: CUSTOMER, CLERK, DRIVER, MANAGER.
 */
package smartship.model;

public class User {
    private int id;
    private String username;
    private String password;
    private String firstName;
    private String lastName;
    private String role;

    public User(int id, String username, String password,
                String firstName, String lastName, String role) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
        this.role = role;
    }

    public int getId() { return id; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getRole() { return role; }
}
