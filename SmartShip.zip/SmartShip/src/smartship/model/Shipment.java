/**
 * Shipment model class.
 *
 * Represents a shipping transaction created by a customer.
 * Connected to Packages (packages table), Invoices (invoices table),
 * Assignments (assignments table), and Vehicles / Routes indirectly.
 */
package smartship.model;

public class Shipment {

    private int id;
    private String shipmentNumber;
    private int customerId;
    private String senderInfo;
    private String recipientInfo;
    private int zone;
    private double distanceKm;
    private double weight;
    private String packageType;
    private double cost;
    private String status;
    private String dateCreated;   // optional; map from date_created if you like

    // ---- Constructors ----

    /** No-arg constructor so we can create and then set fields one by one if needed. */
    public Shipment() {
    }

    /** Convenience constructor used when a customer creates a shipment from the UI. */
    public Shipment(int customerId,
                    String senderInfo,
                    String recipientInfo,
                    int zone,
                    double weight,
                    String packageType) {
        this.customerId = customerId;
        this.senderInfo = senderInfo;
        this.recipientInfo = recipientInfo;
        this.zone = zone;
        this.weight = weight;
        this.packageType = packageType;
    }

    // ---- Getters & Setters ----

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getShipmentNumber() {
        return shipmentNumber;
    }

    public void setShipmentNumber(String shipmentNumber) {
        this.shipmentNumber = shipmentNumber;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getSenderInfo() {
        return senderInfo;
    }

    public void setSenderInfo(String senderInfo) {
        this.senderInfo = senderInfo;
    }

    public String getRecipientInfo() {
        return recipientInfo;
    }

    public void setRecipientInfo(String recipientInfo) {
        this.recipientInfo = recipientInfo;
    }

    public int getZone() {
        return zone;
    }

    public void setZone(int zone) {
        this.zone = zone;
    }

    public double getDistanceKm() {
        return distanceKm;
    }

    public void setDistanceKm(double distanceKm) {
        this.distanceKm = distanceKm;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public String getPackageType() {
        return packageType;
    }

    public void setPackageType(String packageType) {
        this.packageType = packageType;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(String dateCreated) {
        this.dateCreated = dateCreated;
    }
}
