/**
 * ClerkDAO
 *
 * Provides database operations that are specific to the Clerk role:
 *  - Retrieve all shipments that are still PENDING.
 *  - Retrieve list of drivers, vehicles, and schedules for assignment.
 *  - Assign a shipment to a driver and schedule and mark it as ASSIGNED.
 */
package smartship.dao;

import smartship.db.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClerkDAO {

    // Get all shipments that haven't been assigned yet
    public List<String[]> getPendingShipments() {
        List<String[]> list = new ArrayList<>();
        String sql = "SELECT id, shipment_number, sender_info, recipient_info, cost FROM shipments WHERE status = 'PENDING'";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(new String[]{
                        String.valueOf(rs.getInt("id")),
                        rs.getString("shipment_number"),
                        rs.getString("sender_info"),
                        rs.getString("recipient_info"),
                        String.valueOf(rs.getDouble("cost"))
                });
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }


    // Get all drivers
    public List<String[]> getDrivers() {
        List<String[]> list = new ArrayList<>();
        String sql = "SELECT id, first_name, last_name FROM users WHERE role = 'DRIVER'";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(new String[]{
                        String.valueOf(rs.getInt("id")),
                        rs.getString("first_name") + " " + rs.getString("last_name")
                });
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }


    // Get all vehicles
    public List<String[]> getVehicles() {
        List<String[]> list = new ArrayList<>();
        String sql = "SELECT id, license_plate FROM vehicles";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(new String[]{
                        String.valueOf(rs.getInt("id")),
                        rs.getString("license_plate")
                });
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }


    // Get all schedules (e.g. today)
    public List<String[]> getSchedules() {
        List<String[]> list = new ArrayList<>();
        String sql = "SELECT id, start_time, end_time FROM vehicle_schedule";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(new String[]{
                        String.valueOf(rs.getInt("id")),
                        rs.getString("start_time") + " → " + rs.getString("end_time")
                });
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }


    // Assign shipment
    public boolean assignShipment(int shipmentId, int driverId, int scheduleId, int clerkId) {
        String sql = "INSERT INTO assignments (shipment_id, driver_id, schedule_id, assigned_by) VALUES (?, ?, ?, ?)";
        String updateShipment = "UPDATE shipments SET status = 'ASSIGNED' WHERE id = ?";

        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);

            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, shipmentId);
                ps.setInt(2, driverId);
                ps.setInt(3, scheduleId);
                ps.setInt(4, clerkId);
                ps.executeUpdate();
            }

            try (PreparedStatement ps2 = conn.prepareStatement(updateShipment)) {
                ps2.setInt(1, shipmentId);
                ps2.executeUpdate();
            }

            conn.commit();
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
