/**
 * DriverDAO
 *
 * Data access operations for the Driver role:
 *  - Load shipments assigned to a specific driver.
 *  - Update the status of a shipment (IN_TRANSIT, DELIVERED, etc.).
 */
package smartship.dao;

import smartship.db.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DriverDAO {

    // Load shipments assigned to this driver
    public List<String[]> getAssignedShipments(int driverId) {
        List<String[]> list = new ArrayList<>();

        String sql = """
                SELECT s.id, s.shipment_number, s.sender_info, s.recipient_info, s.status
                FROM shipments s
                JOIN assignments a ON a.shipment_id = s.id
                WHERE a.driver_id = ?
                """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, driverId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                list.add(new String[]{
                        String.valueOf(rs.getInt("id")),
                        rs.getString("shipment_number"),
                        rs.getString("sender_info"),
                        rs.getString("recipient_info"),
                        rs.getString("status")
                });
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }


    // Update shipment status
    public boolean updateShipmentStatus(int shipmentId, String status) {
        String sql = "UPDATE shipments SET status = ? WHERE id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, status);
            ps.setInt(2, shipmentId);
            ps.executeUpdate();
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
