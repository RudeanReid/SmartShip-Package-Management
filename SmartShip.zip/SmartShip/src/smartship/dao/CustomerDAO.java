package smartship.dao;

import smartship.db.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CustomerDAO {

    /**
     * Registers a new customer in the system.
     * 1) Inserts into users table with role = 'CUSTOMER'
     * 2) Inserts into customers table referencing the new user id
     *
     * @return true if successful, false otherwise.
     */
    public boolean registerCustomer(String username,
                                    String password,
                                    String firstName,
                                    String lastName,
                                    String phone,
                                    String email,
                                    String address,
                                    String paymentMethod) {

        String insertUserSql =
                "INSERT INTO users (username, password, first_name, last_name, phone, email, role) " +
                "VALUES (?, ?, ?, ?, ?, ?, 'CUSTOMER')";

        String insertCustomerSql =
                "INSERT INTO customers (user_id, billing_address, payment_method) " +
                "VALUES (?, ?, ?)";

        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);

            int userId;

            try (PreparedStatement ps = conn.prepareStatement(insertUserSql,
                    PreparedStatement.RETURN_GENERATED_KEYS)) {

                ps.setString(1, username);
                ps.setString(2, password);
                ps.setString(3, firstName);
                ps.setString(4, lastName);
                ps.setString(5, phone);
                ps.setString(6, email);

                ps.executeUpdate();

                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        userId = rs.getInt(1);
                    } else {
                        conn.rollback();
                        return false;
                    }
                }
            }

            try (PreparedStatement ps2 = conn.prepareStatement(insertCustomerSql)) {
                ps2.setInt(1, userId);
                ps2.setString(2, address);
                ps2.setString(3, paymentMethod);
                ps2.executeUpdate();
            }

            conn.commit();
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
