/**
 * ShipmentDAO
 *
 * Handles all database operations related to Shipments:
 *  - Creating a new shipment
 *  - Creating the corresponding package
 *  - Generating an invoice
 *  - Tracking a shipment by shipment_number
 *
 * It also encapsulates the distance and cost calculation logic.
 */

package smartship.dao;

import smartship.db.DBConnection;
import smartship.model.Shipment;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;

public class ShipmentDAO {

    /**
     * Generates a random distance in KM based on the zone (1-4).
     * This simulates the route distance between origin and destination.
     */
    private double generateDistanceForZone(int zone) {
        Random r = new Random();
        switch (zone) {
            case 1: return 1 + r.nextInt(10);      // 1 - 10 km
            case 2: return 10 + r.nextInt(20);     // 10 - 30
            case 3: return 30 + r.nextInt(30);     // 30 - 60
            case 4: return 60 + r.nextInt(40);     // 60 - 100
            default: return 10;
        }
    }

    /**
     * Calculates the shipping cost based on weight, distance and package type.
     */
    private double calculateCost(double weight, double distanceKm, String type) {
        double base = 500; // base fee
        double weightCost = weight * 50;
        double distanceCost = distanceKm * 20;
        double typeMultiplier = 1.0;
        if ("EXPRESS".equalsIgnoreCase(type)) typeMultiplier = 1.5;
        if ("FRAGILE".equalsIgnoreCase(type)) typeMultiplier = 1.3;
        return (base + weightCost + distanceCost) * typeMultiplier;
    }

    private String generateShipmentNumber() {
        return "SHP" + System.currentTimeMillis();
    }

    /**
     * Returns the customers.id row that belongs to a given users.id.
     * If none exists, returns -1.
     */
    public int findCustomerIdByUserId(int userId) {
        String sql = "SELECT id FROM customers WHERE user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;
    }

    /**
     * Creates a shipment + package + invoice in a single transaction.
     *
     * IMPORTANT:
     *  - Shipment.getCustomerId() MUST be a valid customers.id
     *    (not users.id) to satisfy the foreign key constraint.
     */
    public String createShipment(Shipment s,
                                 double length, double height, double pkgWeight) {

        String shipmentNumber = generateShipmentNumber();
        double distance = generateDistanceForZone(s.getZone());
        double cost = calculateCost(s.getWeight(), distance, s.getPackageType());

        String insertShipment = "INSERT INTO shipments " +
                "(shipment_number, customer_id, sender_info, recipient_info, " +
                "zone, distance_km, weight, package_type, cost, status) " +
                "VALUES (?,?,?,?,?,?,?,?,?, 'PENDING')";

        String insertPackage = "INSERT INTO packages " +
                "(shipment_id, length_cm, height_cm, weight_kg, status) " +
                "VALUES (?,?,?,?, 'READY')";

        String insertInvoice = "INSERT INTO invoices " +
                "(shipment_id, total_amount, paid_amount, status) " +
                "VALUES (?,?,0,'UNPAID')";

        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);

            int shipmentId;
            try (PreparedStatement ps = conn.prepareStatement(insertShipment,
                    Statement.RETURN_GENERATED_KEYS)) {

                ps.setString(1, shipmentNumber);
                ps.setInt(2, s.getCustomerId());
                ps.setString(3, s.getSenderInfo());
                ps.setString(4, s.getRecipientInfo());
                ps.setInt(5, s.getZone());
                ps.setDouble(6, distance);
                ps.setDouble(7, s.getWeight());
                ps.setString(8, s.getPackageType());
                ps.setDouble(9, cost);

                ps.executeUpdate();

                try (ResultSet rs = ps.getGeneratedKeys()) {
                    rs.next();
                    shipmentId = rs.getInt(1);
                }
            }

            try (PreparedStatement psPkg = conn.prepareStatement(insertPackage)) {
                psPkg.setInt(1, shipmentId);
                psPkg.setDouble(2, length);
                psPkg.setDouble(3, height);
                psPkg.setDouble(4, pkgWeight);
                psPkg.executeUpdate();
            }

            try (PreparedStatement psInv = conn.prepareStatement(insertInvoice)) {
                psInv.setInt(1, shipmentId);
                psInv.setDouble(2, cost);
                psInv.executeUpdate();
            }

            conn.commit();
            return shipmentNumber;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Generic tracking by shipment number (for manager / staff views).
     */
    public ResultSet trackShipment(String shipmentNumber) throws SQLException {
        String sql = "SELECT * FROM shipments WHERE shipment_number = ?";
        Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, shipmentNumber);
        return ps.executeQuery();
    }

    /**
     * Secure tracking for a logged-in customer.
     * Ensures the shipment belongs to a customer whose user_id = given userId.
     */
    public ResultSet trackShipmentForCustomer(String shipmentNumber, int userId) {
        ResultSet rs = null;

        String sql =
                "SELECT s.* " +
                "FROM shipments s " +
                "JOIN customers c ON s.customer_id = c.id " +
                "WHERE s.shipment_number = ? AND c.user_id = ?";

        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                    sql,
                    ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY
            );
            ps.setString(1, shipmentNumber);
            ps.setInt(2, userId);
            rs = ps.executeQuery();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rs;
    }
}
