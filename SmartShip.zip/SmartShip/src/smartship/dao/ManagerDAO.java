/**
 * ManagerDAO
 *
 * Provides aggregate reporting and analytics for the Manager role:
 *  - Overall shipment counts and status breakdown.
 *  - Overall revenue and paid amount.
 *  - List of shipments with filters by status or date range.
 *  - Driver performance statistics (how many shipments delivered by each driver).
 */
package smartship.dao;

import smartship.db.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ManagerDAO {

    // ---------- SUMMARY METRICS ----------

    public int getTotalShipments() {
        String sql = "SELECT COUNT(*) FROM shipments";
        return getInt(sql);
    }

    public int getStatusCount(String status) {
        String sql = "SELECT COUNT(*) FROM shipments WHERE status = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, status);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public double getTotalRevenue() {
        String sql = "SELECT IFNULL(SUM(total_amount),0) FROM invoices";
        return getDouble(sql);
    }

    public double getTotalPaid() {
        String sql = "SELECT IFNULL(SUM(paid_amount),0) FROM invoices";
        return getDouble(sql);
    }

    private int getInt(String sql) {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) return rs.getInt(1);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    private double getDouble(String sql) {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) return rs.getDouble(1);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    // ---------- SHIPMENTS LIST ----------

    public List<String[]> getAllShipments() {
        String sql = "SELECT shipment_number, status, date_created, zone, weight, cost FROM shipments ORDER BY date_created DESC";
        return getShipmentsFromQuery(sql, null, null, null);
    }

    public List<String[]> getShipmentsByStatus(String status) {
        String sql = "SELECT shipment_number, status, date_created, zone, weight, cost " +
                     "FROM shipments WHERE status = ? ORDER BY date_created DESC";
        return getShipmentsFromQuery(sql, status, null, null);
    }

    public List<String[]> getShipmentsByDateRange(String fromDate, String toDate) {
        String sql = "SELECT shipment_number, status, date_created, zone, weight, cost " +
                     "FROM shipments WHERE DATE(date_created) BETWEEN ? AND ? ORDER BY date_created DESC";
        return getShipmentsFromQuery(sql, null, fromDate, toDate);
    }

    private List<String[]> getShipmentsFromQuery(String sql,
                                                 String status,
                                                 String fromDate,
                                                 String toDate) {
        List<String[]> list = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            int idx = 1;
            if (status != null) {
                ps.setString(idx++, status);
            }
            if (fromDate != null && toDate != null) {
                ps.setString(idx++, fromDate);
                ps.setString(idx++, toDate);
            }

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new String[]{
                        rs.getString("shipment_number"),
                        rs.getString("status"),
                        rs.getString("date_created"),
                        String.valueOf(rs.getInt("zone")),
                        String.valueOf(rs.getDouble("weight")),
                        String.valueOf(rs.getDouble("cost"))
                });
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // ---------- DRIVER PERFORMANCE ----------

    public List<String[]> getDriverStats() {
        List<String[]> list = new ArrayList<>();

        String sql =
                "SELECT u.first_name, u.last_name, " +
                "       COUNT(s.id) AS totalShipments, " +
                "       SUM(CASE WHEN s.status = 'DELIVERED' THEN 1 ELSE 0 END) AS deliveredShipments " +
                "FROM users u " +
                "JOIN assignments a ON a.driver_id = u.id " +
                "JOIN shipments s ON s.id = a.shipment_id " +
                "WHERE u.role = 'DRIVER' " +
                "GROUP BY u.id";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String name = rs.getString("first_name") + " " + rs.getString("last_name");
                String total = String.valueOf(rs.getInt("totalShipments"));
                String delivered = String.valueOf(rs.getInt("deliveredShipments"));

                list.add(new String[]{name, total, delivered});
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}
