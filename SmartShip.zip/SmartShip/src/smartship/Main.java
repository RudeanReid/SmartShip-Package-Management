/**
 * Entry point for the SmartShip application.
 *
 * Responsibilities:
 *  - Starts the Swing UI on the Event Dispatch Thread (EDT).
 *  - Opens the LoginFrame so users can log in based on their role.
 */
package smartship;

import javax.swing.SwingUtilities;
import smartship.ui.LoginFrame;

public class Main {
    public static void main(String[] args) {
        // Ensure all Swing code runs on the EDT (best practice for Swing apps)
        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}
