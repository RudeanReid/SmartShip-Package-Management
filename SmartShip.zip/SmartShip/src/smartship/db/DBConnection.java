/**
 * DBConnection
 *
 * Utility class responsible for creating connections to the MySQL database.
 * This class hides the JDBC URL, username and password from the rest of the app.
 *
 * The class uses a static initializer block to load the MySQL JDBC driver once.
 */
package smartship.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    // Change these values if your MySQL credentials are different
    private static final String URL = "jdbc:mysql://localhost:3306/smartship";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    static {
        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * Opens and returns a new JDBC connection to the SmartShip database.
     *
     * @return a valid SQL Connection
     * @throws SQLException if the connection cannot be created
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
